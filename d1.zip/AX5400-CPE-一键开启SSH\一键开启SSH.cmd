@echo off
chcp 65001 >nul
setlocal
title 小米 AX5400 5G CPE 一键配置

set "ROUTER_ADDR=%~1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0一键开启SSH并安装.ps1" -Router "%ROUTER_ADDR%"
set "RESULT=%ERRORLEVEL%"

echo.
if "%RESULT%"=="0" (
    echo 配置完成，可以关闭此窗口。
) else (
    echo 操作未完成，请保留或截图上面的错误信息。
)
echo.
pause
exit /b %RESULT%
