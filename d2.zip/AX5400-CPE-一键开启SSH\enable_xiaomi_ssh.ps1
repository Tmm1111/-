﻿[CmdletBinding()]
param(
    [string]$Router = "http://192.168.31.1",
    [switch]$NoPause
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

try {
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
} catch {
    # 输出编码设置失败不影响主流程。
}

$ExpectedHardware = "CB0401V2"
$EncryptKey = "a2ffa5c9be07488bbb04a3a47d3c5f6a"
$RequestTimeoutSeconds = 10

function Write-Step {
    param([string]$Message)
    Write-Host ("[+] " + $Message) -ForegroundColor Cyan
}

function Write-WarnLine {
    param([string]$Message)
    Write-Host ("[!] " + $Message) -ForegroundColor Yellow
}

function Stop-WithError {
    param(
        [string]$Message,
        [int]$Code = 1
    )
    Write-Host ("[-] " + $Message) -ForegroundColor Red
    exit $Code
}

function Get-ObjectProperty {
    param(
        $Object,
        [string]$Name
    )
    if ($null -eq $Object) {
        return $null
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $null
    }
    return $property.Value
}

function Get-HexHash {
    param(
        [ValidateSet("SHA1", "SHA256")]
        [string]$Algorithm,
        [string]$Text
    )

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $hasher = $null
    try {
        if ($Algorithm -eq "SHA256") {
            $hasher = [System.Security.Cryptography.SHA256]::Create()
        } else {
            $hasher = [System.Security.Cryptography.SHA1]::Create()
        }
        $digest = $hasher.ComputeHash($bytes)
        return ([System.BitConverter]::ToString($digest)).Replace("-", "").ToLowerInvariant()
    } finally {
        if ($null -ne $hasher) {
            $hasher.Dispose()
        }
        if ($null -ne $bytes) {
            [System.Array]::Clear($bytes, 0, $bytes.Length)
        }
    }
}

function Invoke-RouterRequest {
    param(
        [string]$Uri,
        $Session,
        [ValidateSet("GET", "POST")]
        [string]$Method = "GET",
        $Body = $null
    )

    $parameters = @{
        Uri                = $Uri
        Method             = $Method
        WebSession         = $Session
        UseBasicParsing    = $true
        TimeoutSec         = $RequestTimeoutSeconds
        MaximumRedirection = 5
        Headers            = @{ "User-Agent" = "Xiaomi-CB0401V2-SSH-Enabler/1.0" }
    }
    if ($Method -eq "POST") {
        $parameters["Body"] = $Body
        $parameters["ContentType"] = "application/x-www-form-urlencoded"
    }
    return Invoke-WebRequest @parameters
}

function Invoke-RouterJson {
    param(
        [string]$Uri,
        $Session,
        [ValidateSet("GET", "POST")]
        [string]$Method = "GET",
        $Body = $null
    )

    $response = Invoke-RouterRequest -Uri $Uri -Session $Session -Method $Method -Body $Body
    try {
        return $response.Content | ConvertFrom-Json
    } catch {
        throw "路由器返回的不是有效 JSON：$Uri"
    }
}

function Test-TcpPort {
    param(
        [string]$HostName,
        [int]$Port,
        [int]$TimeoutMilliseconds = 800
    )

    $client = New-Object System.Net.Sockets.TcpClient
    $asyncResult = $null
    try {
        $asyncResult = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $asyncResult.AsyncWaitHandle.WaitOne($TimeoutMilliseconds, $false)) {
            return $false
        }
        $client.EndConnect($asyncResult)
        return $true
    } catch {
        return $false
    } finally {
        if ($null -ne $asyncResult -and $null -ne $asyncResult.AsyncWaitHandle) {
            $asyncResult.AsyncWaitHandle.Close()
        }
        $client.Close()
    }
}

function ConvertTo-RouterBoolean {
    param($Value)
    if ($Value -is [bool]) {
        return $Value
    }
    if ($null -eq $Value) {
        return $false
    }
    return (([string]$Value).Trim().ToLowerInvariant() -in @("1", "true", "yes", "on"))
}

function ConvertTo-Base64Text {
    param([string]$Text)
    return [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Text))
}

function Invoke-MacFilterSshBootstrap {
    param(
        [string]$ApiBase,
        $Session,
        [string]$RootPassword
    )

    if ($RootPassword.IndexOf("`r") -ge 0 -or $RootPassword.IndexOf("`n") -ge 0) {
        throw "root SSH 密码不能包含换行符。"
    }

    # 通过 CB0401V2 已认证后台的官方维护入口启用固件自带的 Dropbear。
    $stamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $encodedPassword = ConvertTo-Base64Text -Text $RootPassword
    $command = @(
        "sed -i 's/release/XXXXXX/g' /etc/init.d/dropbear",
        "nvram set ssh_en=1",
        "nvram set boot_wait=on",
        "nvram set bootdelay=3",
        "nvram commit",
        "printf '$encodedPassword' | base64 -d >/tmp/ax5400-root-pass",
        "{ cat /tmp/ax5400-root-pass; printf '\n'; cat /tmp/ax5400-root-pass; printf '\n'; } | passwd root",
        "rm -f /tmp/ax5400-root-pass",
        "/etc/init.d/dropbear enable",
        "/etc/init.d/dropbear restart",
        "if [ -e /dev/ttyUSB2 ] && command -v microcom >/dev/null 2>&1; then printf 'AT+QNWPREFCFG=`"nr5g_disable_mode`",0\r' | microcom -t 6000 /dev/ttyUSB2 >/tmp/ax5400-enable-5g.log 2>&1 || true; fi"
    ) -join "; "
    $payload = "xxx ; uci set diag.config.usb_read_thr=$stamp ; uci commit diag ; $command"

    foreach ($option in @("0", "1")) {
        $response = Invoke-RouterRequest -Uri "$ApiBase/set_mac_filter" -Session $Session -Method "POST" -Body @{
            mac    = "00:00:00:00:00:33"
            name   = $payload
            option = $option
            wan    = ""
        }
        if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
            throw "set_mac_filter 请求失败（HTTP $($response.StatusCode)）。"
        }
    }
}

function Set-RouterLanguageToChinese {
    param(
        [string]$ApiBase,
        $Session
    )

    $result = Invoke-RouterJson -Uri "$ApiBase/set_language" -Session $Session -Method "POST" -Body @{
        language = "zh"
    }
    $code = Get-ObjectProperty -Object $result -Name "code"
    if ([string]$code -ne "0") {
        throw "后台返回 code: $code"
    }
}

Write-Host ""
Write-Host "小米 AX5400 5G CPE（CB0401V2）一键中文配置与 SSH" -ForegroundColor Green
Write-Host "通过已认证后台切换中文并启用固件自带的 SSH；不会升级系统，不会刷写分区。"
Write-Host ""

if ([string]::IsNullOrWhiteSpace($Router)) {
    $Router = "http://192.168.31.1"
}
if ($Router -notmatch "^[a-zA-Z][a-zA-Z0-9+.-]*://") {
    $Router = "http://" + $Router
}

try {
    $routerUri = [Uri]$Router
} catch {
    Stop-WithError "后台地址格式不正确：$Router"
}

if (-not $routerUri.IsAbsoluteUri -or $routerUri.Scheme -notin @("http", "https")) {
    Stop-WithError "后台地址必须是 http:// 或 https:// 地址。"
}
if (-not [string]::IsNullOrEmpty($routerUri.UserInfo)) {
    Stop-WithError "后台地址中不能包含用户名或密码。"
}

$BaseUrl = $routerUri.GetLeftPart([System.UriPartial]::Authority).TrimEnd("/")
$RouterHost = $routerUri.DnsSafeHost

if ($routerUri.Scheme -eq "https") {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$initInfo = $null
$loginHtml = $null

Write-Step "连接后台：$BaseUrl"
try {
    $initInfo = Invoke-RouterJson -Uri "$BaseUrl/cgi-bin/luci/api/xqsystem/init_info" -Session $session
} catch {
    Write-WarnLine "未能读取 init_info，将从登录页继续识别设备。"
}

$loginPaths = @(
    "/cgi-bin/luci/web/login",
    "/cgi-bin/luci/"
)
foreach ($path in $loginPaths) {
    try {
        $loginHtml = (Invoke-RouterRequest -Uri ($BaseUrl + $path) -Session $session).Content
        if (-not [string]::IsNullOrWhiteSpace($loginHtml)) {
            break
        }
    } catch {
        $loginHtml = $null
    }
}
if ([string]::IsNullOrWhiteSpace($loginHtml)) {
    Stop-WithError "无法打开后台登录页。请确认电脑已连接这台 CPE，地址为 $BaseUrl。"
}

$hardware = [string](Get-ObjectProperty -Object $initInfo -Name "hardware")
if ([string]::IsNullOrWhiteSpace($hardware)) {
    $hardwareMatch = [regex]::Match(
        $loginHtml,
        '(?i)\bhardware\s*=\s*[''"](?<hardware>[^''"]+)[''"]'
    )
    if ($hardwareMatch.Success) {
        $hardware = $hardwareMatch.Groups["hardware"].Value
    }
}
if ([string]::IsNullOrWhiteSpace($hardware)) {
    Stop-WithError "无法确认设备型号，已停止操作；本脚本只允许用于 $ExpectedHardware。"
}
if (-not $hardware.Equals($ExpectedHardware, [System.StringComparison]::OrdinalIgnoreCase)) {
    Stop-WithError "设备型号是 $hardware，不是 $ExpectedHardware；为防止误操作已停止。"
}

$romVersion = [string](Get-ObjectProperty -Object $initInfo -Name "romversion")
if ([string]::IsNullOrWhiteSpace($romVersion)) {
    Write-Step "型号确认：$hardware"
} else {
    Write-Step "型号确认：$hardware，系统版本：$romVersion"
}

$macPattern = '(?is)nonceCreat.{0,800}?\bdeviceId\s*=\s*[''"](?<mac>[0-9a-f]{2}(?:(?:[:-]?[0-9a-f]{2})){5})[''"]'
$macMatch = [regex]::Match($loginHtml, $macPattern)
if (-not $macMatch.Success) {
    $macPattern = '(?i)\bdeviceId\s*=\s*[''"](?<mac>[0-9a-f]{2}(?:(?:[:-]?[0-9a-f]{2})){5})[''"]'
    $macMatch = [regex]::Match($loginHtml, $macPattern)
}
if (-not $macMatch.Success) {
    Stop-WithError "登录页没有返回本机 MAC。请直接连接 CPE 的 LAN/Wi-Fi 后重试。"
}
$clientMac = $macMatch.Groups["mac"].Value

$modeValue = Get-ObjectProperty -Object $initInfo -Name "newEncryptMode"
$modeKnown = ($null -ne $modeValue -and -not [string]::IsNullOrWhiteSpace([string]$modeValue))
$algorithms = @("SHA1")
if ($modeKnown -and [string]$modeValue -eq "1") {
    $algorithms = @("SHA256")
} elseif (-not $modeKnown) {
    # 极少数固件不返回加密模式，此时先按当前固件的 SHA1，再兼容尝试 SHA256。
    $algorithms = @("SHA1", "SHA256")
}

Write-Host "请输入小米后台管理密码（输入时不会显示，也不会保存）：" -ForegroundColor White
$securePassword = Read-Host -AsSecureString
$passwordPointer = [IntPtr]::Zero
$plainPassword = $null
try {
    $passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
    $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
} finally {
    if ($passwordPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
    }
    $securePassword.Dispose()
}
if ([string]::IsNullOrEmpty($plainPassword)) {
    Stop-WithError "密码不能为空。"
}

Write-Step "登录后台"
$token = $null
$lastLoginCode = $null
try {
    foreach ($algorithm in $algorithms) {
        $nonce = "0_{0}_{1}_{2}" -f $clientMac, [DateTimeOffset]::UtcNow.ToUnixTimeSeconds(), (Get-Random -Minimum 0 -Maximum 10000)
        $innerHash = Get-HexHash -Algorithm $algorithm -Text ($plainPassword + $EncryptKey)
        $loginHash = Get-HexHash -Algorithm $algorithm -Text ($nonce + $innerHash)
        $loginBody = @{
            username = "admin"
            password = $loginHash
            logtype  = "2"
            nonce    = $nonce
        }

        try {
            $loginResult = Invoke-RouterJson -Uri "$BaseUrl/cgi-bin/luci/api/xqsystem/login" -Session $session -Method "POST" -Body $loginBody
        } catch {
            $lastLoginCode = "HTTP 请求失败"
            continue
        } finally {
            $innerHash = $null
            $loginHash = $null
            $loginBody = $null
        }

        $lastLoginCode = Get-ObjectProperty -Object $loginResult -Name "code"
        if ([string]$lastLoginCode -eq "0") {
            $candidateToken = [string](Get-ObjectProperty -Object $loginResult -Name "token")
            if ($candidateToken -match "^[A-Za-z0-9_-]{8,128}$") {
                $token = $candidateToken
                break
            }
        }
        if ([string]$lastLoginCode -eq "403") {
            break
        }
    }
} finally {
    $plainPassword = $null
}

if ([string]::IsNullOrWhiteSpace($token)) {
    if ([string]$lastLoginCode -eq "403") {
        Stop-WithError "登录被后台暂时限制（code 403）。请稍等一会儿再试，不要连续输入密码。"
    }
    Stop-WithError "后台登录失败（code: $lastLoginCode）。请检查管理密码后再试。"
}

$ApiBase = "$BaseUrl/cgi-bin/luci/;stok=$token/api/xqsystem"
Write-Step "将系统界面切换为简体中文"
try {
    Set-RouterLanguageToChinese -ApiBase $ApiBase -Session $session
} catch {
    Stop-WithError "切换中文失败：$($_.Exception.Message)"
}

if (Test-TcpPort -HostName $RouterHost -Port 22) {
    Write-Host "[OK] 系统已为简体中文，SSH 已经开启。" -ForegroundColor Green
    Write-Host "连接命令：ssh root@$RouterHost"
    exit 0
}

Write-Host "请输入要设置的 root SSH 密码（输入时不会显示，也不会保存）：" -ForegroundColor White
$secureRootPassword = Read-Host -AsSecureString
$rootPasswordPointer = [IntPtr]::Zero
$plainRootPassword = $null
try {
    $rootPasswordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureRootPassword)
    $plainRootPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($rootPasswordPointer)
} finally {
    if ($rootPasswordPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($rootPasswordPointer)
    }
    $secureRootPassword.Dispose()
}
if ([string]::IsNullOrEmpty($plainRootPassword)) {
    Stop-WithError "root SSH 密码不能为空。"
}

Write-Step "通过官方维护入口开启 SSH 服务"
$bootstrapError = $null
try {
    Invoke-MacFilterSshBootstrap -ApiBase $ApiBase -Session $session -RootPassword $plainRootPassword
} catch {
    $bootstrapError = $_.Exception.Message
} finally {
    $plainRootPassword = $null
}
if ($null -ne $bootstrapError) {
    Stop-WithError "SSH 开启请求失败：$bootstrapError"
}

Write-Step "等待 SSH 服务启动并验证 TCP 22 端口"
$portOpen = $false
for ($attempt = 1; $attempt -le 40; $attempt++) {
    if (Test-TcpPort -HostName $RouterHost -Port 22) {
        $portOpen = $true
        break
    }
    Start-Sleep -Milliseconds 500
}

if ($portOpen) {
    Write-Host ""
    Write-Host "[OK] SSH 已成功开启，22 端口可连接。" -ForegroundColor Green
    Write-Host "连接命令：ssh root@$RouterHost"
    Write-Host "用户名：root"
    Write-Host "系统界面已切换为简体中文。"
    Write-Host "已同时提交允许 5G SA/NSA 的模组命令。"
    Write-Host "脚本没有升级系统，也没有刷写任何分区。"
    exit 0
}

Stop-WithError "已提交 SSH 开启请求，但 22 端口未监听。请确认电脑仍连接 CPE 后重试。" 3
