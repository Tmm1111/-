﻿[CmdletBinding()]
param(
    [string]$Router = "http://192.168.31.1"
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$PackageUrl = "https://cdn.jsdelivr.net/gh/Tmm1111/-@8d5da76dca625defafdcaac5650775fae01c1f34/p3"
$PackageSha256 = "5e9497e9f006a9ab6b757a751701cbb9732dced44bca5291d5a132b25d229302"
$RemotePackage = "/tmp/p3"

function Stop-WithError {
    param([string]$Message, [int]$Code = 1)
    Write-Host ("[-] " + $Message) -ForegroundColor Red
    exit $Code
}

function Remove-TemporaryFiles {
    param([string[]]$Paths)
    foreach ($path in $Paths) {
        if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path)) {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        }
    }
}

if ([string]::IsNullOrWhiteSpace($Router)) {
    $Router = "http://192.168.31.1"
}
if ($Router -notmatch "^[a-zA-Z][a-zA-Z0-9+.-]*://") {
    $Router = "http://" + $Router
}
try {
    $routerUri = [Uri]$Router
} catch {
    Stop-WithError "后台地址格式不正确：$Router"
}
if (-not $routerUri.IsAbsoluteUri -or $routerUri.Scheme -notin @("http", "https")) {
    Stop-WithError "后台地址必须是 http:// 或 https:// 地址。"
}
if (-not [string]::IsNullOrEmpty($routerUri.UserInfo)) {
    Stop-WithError "后台地址中不能包含用户名或密码。"
}

$routerHost = $routerUri.DnsSafeHost
$sshEnabler = Join-Path $PSScriptRoot "enable_xiaomi_ssh.ps1"
if (-not (Test-Path -LiteralPath $sshEnabler)) {
    Stop-WithError "工具文件不完整，请重新解压后运行。"
}
foreach ($tool in @("ssh.exe", "scp.exe")) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
        Stop-WithError "Windows 未安装 OpenSSH 客户端，缺少 $tool。"
    }
}

Write-Host ""
Write-Host "小米 AX5400 5G CPE 一键中文配置" -ForegroundColor Green
Write-Host "不会升级系统，不会刷写分区。"
Write-Host ""

Write-Host "[+] 正在切换中文、开启并验证 SSH" -ForegroundColor Cyan
& powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $sshEnabler -Router $Router -NoPause
if ($LASTEXITCODE -ne 0) {
    Stop-WithError "SSH 未成功开启，已停止后续操作。" $LASTEXITCODE
}

$tempPackage = Join-Path $env:TEMP ("ax5400-p3-{0}" -f $PID)
$knownHosts = Join-Path $env:TEMP ("ax5400-known-hosts-{0}" -f $PID)
try {
    Write-Host "[+] 下载并校验扩展包" -ForegroundColor Cyan
    Invoke-WebRequest -Uri $PackageUrl -OutFile $tempPackage -UseBasicParsing -TimeoutSec 120
    $actualHash = (Get-FileHash -LiteralPath $tempPackage -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $PackageSha256) {
        throw "扩展包校验失败，已拒绝安装。"
    }

    $commonArgs = @(
        "-o", "StrictHostKeyChecking=accept-new",
        "-o", "UserKnownHostsFile=$knownHosts",
        "-o", "HostKeyAlgorithms=+ssh-rsa",
        "-o", "PubkeyAcceptedAlgorithms=+ssh-rsa",
        "-o", "ConnectTimeout=10"
    )

    Write-Host "[+] 上传扩展包，请输入 root SSH 密码" -ForegroundColor Cyan
    & scp.exe -O @commonArgs $tempPackage "root@${routerHost}:$RemotePackage"
    if ($LASTEXITCODE -ne 0) {
        throw "上传失败，请检查 root SSH 密码和网络连接。"
    }

    Write-Host "[+] 执行配置，请再次输入 root SSH 密码" -ForegroundColor Cyan
    $remoteCommand = "sh '$RemotePackage' --reinstall; rc=`$?; rm -f '$RemotePackage'; exit `$rc"
    & ssh.exe @commonArgs "root@$routerHost" $remoteCommand
    if ($LASTEXITCODE -ne 0) {
        throw "设备端执行失败，请保留窗口中的错误信息。"
    }
} catch {
    Stop-WithError $_.Exception.Message
} finally {
    Remove-TemporaryFiles -Paths @($tempPackage, $knownHosts)
}

Write-Host ""
Write-Host "[OK] 简体中文、SSH、扩展配置和开机自动启用 5G 均已完成。" -ForegroundColor Green
Write-Host "SSH：root@$routerHost"
Write-Host "刷新设备后台即可使用。"
exit 0
